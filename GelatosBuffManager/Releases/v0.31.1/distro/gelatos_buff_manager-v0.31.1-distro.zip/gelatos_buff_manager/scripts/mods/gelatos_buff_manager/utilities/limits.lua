local mod = get_mod("gelatos_buff_manager")

local ok_settings, PlayerBuffsSettings = pcall(require, "scripts/ui/hud/elements/player_buffs/hud_element_player_buffs_settings")
local LIVE_MAX_BUFFS = ok_settings and type(PlayerBuffsSettings.max_buffs) == "number" and PlayerBuffsSettings.max_buffs or nil

local FALLBACK_MAX_BUFFS_PER_BAR = 20

if not LIVE_MAX_BUFFS then
	mod:info("Gelato's Buff Manager: could not read the live per-bar icon limit; using 20 informationally.")
end

local M = {}

function M.max_buffs_per_bar()
	return LIVE_MAX_BUFFS or FALLBACK_MAX_BUFFS_PER_BAR
end

return M
