local mod = get_mod("gelatos_buff_manager")

local ok_settings, PlayerBuffsSettings = pcall(require, "scripts/ui/hud/elements/player_buffs/hud_element_player_buffs_settings")
local LIVE_MAX_BUFFS = ok_settings and type(PlayerBuffsSettings.max_buffs) == "number" and PlayerBuffsSettings.max_buffs or nil

-- FALLBACK_MAX_BUFFS_PER_BAR is used only if the live value above is unavailable (a patch moved
-- or renamed the settings file); 20 was the vanilla value confirmed at GBM's original release and
-- remains a reasonable informational default. hud_element_buff_bar.lua reads the live value
-- directly for the unified-cap spoof; this module exists only for the UI/log warning threshold.
--
-- CONFIRMED directly from the game's own source (hud_element_player_buffs_settings.lua,
-- hud_element_player_buffs_polling.lua, hud_element_player_buffs_definitions.lua):
--   - This is a PER-INSTANCE cap, not shared across bars: each HudElementPlayerBuffs-derived
--     object (the default bar, or any of our custom bars) gets its own independent array of
--     exactly max_buffs pre-defined "buff_1".."buff_N" widgets.
--   - 3/4 of those slots are reserved for positive buffs and 1/4 for negative (a fixed
--     THREE_QUATER_MAX_BUFF / QUATER_MAX_BUFF split).
--   - Overflow is handled gracefully in the current game version: _get_available_widget()
--     returning nil is null-checked, not a crash (this was a real Fatshark-acknowledged bug,
--     fixed in patch 1.8.6 -- pre-fix, the same nil case crashed the client, and BBM users
--     were told to disable the mod while waiting for that hotfix).
--   - Which buffs actually get a slot when there are more assigned than fit is decided by the
--     game itself: sorted by activation time (oldest surviving buff keeps its slot), then
--     explicit hud_priority if a template sets one. This is smarter than any static
--     pre-truncation we could do, so GBM no longer truncates bar filters at all -- this value
--     is purely an informational threshold for the UI/log warnings, not an enforced cap.
local FALLBACK_MAX_BUFFS_PER_BAR = 20

if not LIVE_MAX_BUFFS then
	mod:info("Gelato's Buff Manager: could not read the live per-bar icon limit; using 20 informationally.")
end

local M = {}

function M.max_buffs_per_bar()
	return LIVE_MAX_BUFFS or FALLBACK_MAX_BUFFS_PER_BAR
end

return M
