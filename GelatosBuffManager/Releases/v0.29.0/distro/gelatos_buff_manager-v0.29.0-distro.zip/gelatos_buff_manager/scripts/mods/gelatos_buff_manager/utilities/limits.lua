local mod = get_mod("gelatos_buff_manager")

local DEFAULT_MAX_BUFFS_PER_BAR = 20

local M = {}

function M.max_buffs_per_bar()
	return DEFAULT_MAX_BUFFS_PER_BAR
end

M.MAX_BUFFS_PER_BAR = DEFAULT_MAX_BUFFS_PER_BAR

return M
