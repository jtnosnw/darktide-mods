local HudElementPlayerBuffsDefinitions = require(
	"scripts/ui/hud/elements/player_buffs/hud_element_player_buffs_definitions"
)
local UIWorkspaceSettings = require("scripts/settings/ui/ui_workspace_settings")

local BAR_SIZE = { 80, 40 }
local BUFF_SIZE = { 38, 38 }

local VANILLA_X = 550
local VANILLA_Y = -50
local VANILLA_STEP = 75
local BAR_STACK_STEP = 50

local CENTER_X = 960
do
	local screen = UIWorkspaceSettings.screen
	if type(screen) == "table" and type(screen.size) == "table" and type(screen.size[1]) == "number"
		and screen.size[1] > 0 then
		CENTER_X = screen.size[1] * 0.5
	end
end

local function build_scenegraph_definition(slot, centered)
	local index = slot or 1
	local y = VANILLA_Y - VANILLA_STEP
	if index > 1 then
		y = y - (index - 1) * BAR_STACK_STEP
	end

	local x = centered and CENTER_X or VANILLA_X

	return {
		screen = UIWorkspaceSettings.screen,
		background = {
			horizontal_alignment = "left",
			parent = "screen",
			vertical_alignment = "bottom",
			size = { BAR_SIZE[1], BAR_SIZE[2] },
			position = { x, y, 1 },
		},
		buff = {
			horizontal_alignment = "left",
			parent = "background",
			vertical_alignment = "bottom",
			size = { BUFF_SIZE[1], BUFF_SIZE[2] },
			position = { 0, 0, 1 },
		},
	}
end

return {
	animations = HudElementPlayerBuffsDefinitions.animations,
	buff_widget_definition = HudElementPlayerBuffsDefinitions.buff_widget_definition,
	widget_definitions = HudElementPlayerBuffsDefinitions.widget_definitions,
	scenegraph_definition = build_scenegraph_definition(1),
	build_scenegraph_definition = build_scenegraph_definition,
	VANILLA_X = VANILLA_X,
	VANILLA_Y = VANILLA_Y,
	BUFF_HALF_WIDTH = BUFF_SIZE[1] * 0.5,
}
