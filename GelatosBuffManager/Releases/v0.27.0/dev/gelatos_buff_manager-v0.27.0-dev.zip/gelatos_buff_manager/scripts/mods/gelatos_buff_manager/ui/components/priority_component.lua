local mod = get_mod("gelatos_buff_manager")
local Imgui_helpers = mod:io_dofile("gelatos_buff_manager/scripts/mods/gelatos_buff_manager/utilities/imgui")
mod:io_dofile("gelatos_buff_manager/scripts/mods/gelatos_buff_manager/ui/components/base_component")
local BuffPriorities = mod:io_dofile(
	"gelatos_buff_manager/scripts/mods/gelatos_buff_manager/utilities/buff_priorities")
local ActionHistory = mod:io_dofile(
	"gelatos_buff_manager/scripts/mods/gelatos_buff_manager/utilities/action_history")

local CLASS_NAME = "PriorityComponent"

-- Static labels resolved once at load; only parameterised strings stay dynamic.
local L = {
	HELP = mod:localize("gbm_priority_help"),
	SET_SELECTED_LABEL = mod:localize("gbm_priority_set_selected_label"),
	APPLY = mod:localize("gbm_priority_apply"),
	RESET_ALL = mod:localize("gbm_priority_reset_all"),
	NO_SELECTION_ERROR = mod:localize("gbm_priority_no_selection_error"),
	WARN_PRIO_NONE = mod:localize("gbm_hist_warn_prio_none"),
}

local SET_PRIORITY_COMBO_ID = CLASS_NAME .. "_SET_PRIORITY"
local CONTROLS_CHILD_ID = CLASS_NAME .. "_CONTROLS"
local HELP_CHILD_ID = CLASS_NAME .. "_HELP"

local PRIORITY_COMBO_ITEMS = { "0", "1 (default)", "2" }
local DEFAULT_COMBO_INDEX = BuffPriorities.DEFAULT + 1
local COMBO_WIDTH = 110
-- Fits label + combo + Apply on one row and the Reset ALL button below.
local CONTROLS_CHILD_SIZE = { 360, 78 }

local PriorityComponent = class(CLASS_NAME, "BaseComponent")

function PriorityComponent:init(nav_tree_component)
	PriorityComponent.super.init(self)

	self._nav_tree_component = nav_tree_component
	self._combo_index = DEFAULT_COMBO_INDEX
	self._action_status = nil
end

function PriorityComponent:_apply_to_selected(priority_value)
	local nav_tree = self._nav_tree_component
	local selected_names = nav_tree and nav_tree:get_selected_names()
	local selected_count = nav_tree and nav_tree:get_selected_count() or 0

	if selected_count == 0 or not selected_names then
		self._action_status = L.NO_SELECTION_ERROR
		ActionHistory.warn(L.WARN_PRIO_NONE)
		return
	end

	BuffPriorities.set_many(selected_names, priority_value)
	self._action_status = mod:localize("gbm_priority_applied", selected_count, priority_value)
	ActionHistory.log(mod:localize("gbm_hist_prio_selected", selected_count, priority_value))
end

function PriorityComponent:update()
	-- Controls in a fixed-width child so the multi-line help renders as an aligned block to
	-- their right (plain text after same_line would wrap follow-on lines back to the pane edge).
	Imgui.begin_child_window(CONTROLS_CHILD_ID, CONTROLS_CHILD_SIZE[1], CONTROLS_CHILD_SIZE[2], false)

	Imgui.text(L.SET_SELECTED_LABEL)
	Imgui.same_line()

	local width_pushed = Imgui_helpers.push_width(COMBO_WIDTH)
	local new_index = Imgui.combo(SET_PRIORITY_COMBO_ID, "", PRIORITY_COMBO_ITEMS, self._combo_index, false)
	Imgui_helpers.pop_width(width_pushed)

	-- Selection alone is inert; only Apply commits it to the selected buffs.
	if new_index then
		self._combo_index = new_index
	end

	Imgui.same_line()
	if Imgui.button(L.APPLY) then
		self:_apply_to_selected(self._combo_index - 1)
	end

	if Imgui.button(L.RESET_ALL) then
		local cleared_count = BuffPriorities.reset_all()
		self._action_status = mod:localize("gbm_priority_reset_all_done", cleared_count)
		ActionHistory.log(mod:localize("gbm_hist_prio_reset_all", cleared_count))
	end

	Imgui.end_child_window()

	Imgui.same_line()

	Imgui.begin_child_window(HELP_CHILD_ID, 0, CONTROLS_CHILD_SIZE[2], false)
	Imgui.text(L.HELP)
	Imgui.end_child_window()

	-- Always reserve this line so the layout doesn't jump when a status appears.
	Imgui.text(self._action_status or "")
end

return PriorityComponent
