local mod = get_mod("gelatos_buff_manager")

-- FALLBACK_MAX_BUFFS_PER_BAR is used only if hud_element_buff_bar.lua (loaded earlier, and the
-- one place that actually needs this value to function) hasn't set the live value below for some
-- reason; 20 was the vanilla value confirmed at GBM's original release and remains a reasonable
-- informational default in that case.
--
-- CONFIRMED directly from the game's own source (hud_element_player_buffs_settings.lua,
-- hud_element_player_buffs_polling.lua, hud_element_player_buffs_definitions.lua):
--   - This is a PER-INSTANCE cap, not shared across bars: each HudElementPlayerBuffs-derived
--     object (the default bar, or any of our custom bars) gets its own independent array of
--     exactly max_buffs pre-defined "buff_1".."buff_N" widgets.
--   - 3/4 of those slots are reserved for positive buffs and 1/4 for negative (a fixed
--     THREE_QUATER_MAX_BUFF / QUATER_MAX_BUFF split).
--   - Overflow is handled gracefully in the current game version: _get_available_widget()
--     returning nil is null-checked, not a crash (this was a real Fatshark-acknowledged bug,
--     fixed in patch 1.8.6 -- pre-fix, the same nil case crashed the client, and BBM users
--     were told to disable the mod while waiting for that hotfix).
--   - Which buffs actually get a slot when there are more assigned than fit is decided by the
--     game itself: sorted by activation time (oldest surviving buff keeps its slot), then
--     explicit hud_priority if a template sets one. This is smarter than any static
--     pre-truncation we could do, so GBM no longer truncates bar filters at all -- this value
--     is purely an informational threshold for the UI/log warnings, not an enforced cap.
local FALLBACK_MAX_BUFFS_PER_BAR = 20

local M = {}

-- Read fresh every call rather than cached once at load: hud_element_buff_bar.lua (loaded before
-- this module anywhere it's used) is the ONE place that requires the game's settings module, so
-- every caller reads the exact same value it uses -- no second, independently-derived lookup that
-- could ever disagree with it.
function M.max_buffs_per_bar()
	local value = mod._gbm_max_buffs
	if type(value) ~= "number" then
		mod:info("Gelato's Buff Manager: the live per-bar icon limit isn't set yet; using 20 informationally.")
		return FALLBACK_MAX_BUFFS_PER_BAR
	end
	return value
end

return M
