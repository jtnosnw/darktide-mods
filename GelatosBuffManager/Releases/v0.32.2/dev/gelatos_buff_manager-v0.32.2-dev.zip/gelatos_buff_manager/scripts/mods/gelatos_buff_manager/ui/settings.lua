return {
	BAR_WINDOW_SIZE = { 0, 150 },
	RECENT_WINDOW_SIZE = { 0, 100 },
	SEARCH_WINDOW_SIZE = { 0, 100 },
	BUFF_WINDOW_SIZE = { 100, 122 },
	BUFF_IMAGE_SIZE = { 64, 64 },
	NAV_WINDOW_SIZE = { 380, 460 },
	-- Negative pane height reserves this strip at the window bottom for ACTION HISTORY.
	HISTORY_PANEL_OFFSET = -136,
	-- First-frame estimate only; the virtualizer measures the real height and self-corrects.
	NAV_ROW_HEIGHT = 57,
}
