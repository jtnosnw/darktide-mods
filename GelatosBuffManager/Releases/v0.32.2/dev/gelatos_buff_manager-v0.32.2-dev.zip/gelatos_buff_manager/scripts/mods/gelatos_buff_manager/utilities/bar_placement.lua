local mod = get_mod("gelatos_buff_manager")
local Definitions = mod:io_dofile(
	"gelatos_buff_manager/scripts/mods/gelatos_buff_manager/hud/hud_element_buff_bar_definitions")
local Limits = mod:io_dofile("gelatos_buff_manager/scripts/mods/gelatos_buff_manager/utilities/limits")

local POSITIONS_SETTING_ID = "gbm_bar_positions"
local SLOTS_SETTING_ID = "gbm_bar_slots"
local GROUP_SETTING_ID = "group_buffs_in_categories"
local PLAYER_BUFFS_SETTINGS_PATH = "scripts/ui/hud/elements/player_buffs/hud_element_player_buffs_settings"
local BUFF_SETTINGS_PATH = "scripts/settings/buff/buff_settings"
local HUD_UTILITY_PATH = "scripts/utilities/ui/hud"

local UI_LIMIT = 100000
local ROUNDING = 1000
local FALLBACK_SPACING = 42
local FALLBACK_WIDTH = 1920
local FALLBACK_HEIGHT = 1080

local ROW_HEIGHT = Definitions.BUFF_NODE_HEIGHT
local NODE_WIDTH = Definitions.BUFF_NODE_WIDTH

local type = type
local pcall = pcall
local math_floor = math.floor
local math_min = math.min
local math_max = math.max
local table_concat = table.concat

local L = {
	EDGE_LEFT = mod:localize("gbm_pos_edge_left"),
	EDGE_RIGHT = mod:localize("gbm_pos_edge_right"),
	EDGE_TOP = mod:localize("gbm_pos_edge_top"),
	EDGE_BOTTOM = mod:localize("gbm_pos_edge_bottom"),
	LIST_SEPARATOR = mod:localize("gbm_pos_list_separator"),
	RISK_JOIN = mod:localize("gbm_pos_risk_join"),
}

-- Per-frame screen snapshot; refresh_screen() updates these in place, no allocation.
local _scale = 1
local _width_px = FALLBACK_WIDTH
local _height_px = FALLBACK_HEIGHT

local _player_buffs_settings = nil
local _hud_utility = nil
local _category_count = nil
local _edges_scratch = {}

local M = {}

M.SETTING_ID = POSITIONS_SETTING_ID

-- ---- Local Functions ----

local function _valid_number(value)
	return type(value) == "number" and value == value and value > -UI_LIMIT and value < UI_LIMIT
end

local function _positive_or(value, fallback)
	return (_valid_number(value) and value > 0) and value or fallback
end

local function _read_store()
	local saved = mod:get(POSITIONS_SETTING_ID)
	return type(saved) == "table" and saved or nil
end

local function _valid_entry(entry)
	return type(entry) == "table" and _valid_number(entry[1]) and _valid_number(entry[2])
end

local function _slot_for(bar_name)
	local slots = mod:get(SLOTS_SETTING_ID)
	local slot = type(slots) == "table" and slots[bar_name] or nil
	return (type(slot) == "number" and slot >= 1) and slot or nil
end

local function _horizontal_spacing()
	if _player_buffs_settings == nil then
		local ok, settings = pcall(require, PLAYER_BUFFS_SETTINGS_PATH)
		_player_buffs_settings = (ok and type(settings) == "table") and settings or false
	end
	local spacing = _player_buffs_settings and _player_buffs_settings.horizontal_spacing
	return _positive_or(spacing, FALLBACK_SPACING)
end

local function _buff_category_count()
	if _category_count == nil then
		local ok, settings = pcall(require, BUFF_SETTINGS_PATH)
		local order = ok and type(settings) == "table" and settings.buff_category_order or nil
		_category_count = type(order) == "table" and #order or 0
	end
	return _category_count
end

-- Width of a single icon row holding buff_count icons, in UI units, capped at the live per-bar limit.
local function _row_width(buff_count)
	local count = math_max(math_min(type(buff_count) == "number" and buff_count or 0, Limits.max_buffs_per_bar()), 1)
	local slots = count - 1
	if mod:get(GROUP_SETTING_ID) then
		local gaps = math_min(count, _buff_category_count()) - 1
		if gaps > 0 then
			slots = slots + gaps * 0.5
		end
	end
	return slots * _horizontal_spacing() + NODE_WIDTH
end

-- Returns left, right (UI units from screen left) and top, bottom (UI units from screen bottom, <= 0 on screen).
local function _bounds(x, y, growth, buff_count)
	local width = _row_width(buff_count)
	local left = x
	if growth == "center" then
		left = x - width * 0.5
	elseif growth == "right_left" then
		left = x - width
	end
	return left, left + width, y - ROW_HEIGHT, y
end

-- ---- Screen ----

-- Full render scale for use_hud_scale elements, matching UIHud._add_element / _apply_hud_scale.
function M.hud_scale()
	if _hud_utility == nil then
		local ok, hud = pcall(require, HUD_UTILITY_PATH)
		_hud_utility = (ok and type(hud) == "table" and type(hud.hud_scale) == "function") and hud or false
	end

	if _hud_utility then
		local ok, scale = pcall(_hud_utility.hud_scale)
		if ok and _valid_number(scale) and scale > 0 then
			return scale
		end
	end

	local lookup = rawget(_G, "RESOLUTION_LOOKUP")
	return _positive_or(lookup and lookup.scale, 1)
end

function M.refresh_screen()
	local lookup = rawget(_G, "RESOLUTION_LOOKUP")
	_scale = M.hud_scale()
	_width_px = _positive_or(lookup and lookup.width, FALLBACK_WIDTH)
	_height_px = _positive_or(lookup and lookup.height, FALLBACK_HEIGHT)
end

function M.ui_to_px(x, y)
	return math_floor(x * _scale + 0.5), math_floor(_height_px + (y - ROW_HEIGHT) * _scale + 0.5)
end

function M.px_to_ui(px_x, px_y)
	local x = math_floor(px_x / _scale * ROUNDING + 0.5) / ROUNDING
	local y = math_floor(((px_y - _height_px) / _scale + ROW_HEIGHT) * ROUNDING + 0.5) / ROUNDING
	return x, y
end

-- Keeps the anchor on screen and the icon row's top/bottom inside the screen height.
function M.clamp_px(px_x, px_y)
	local max_y = math_max(math_floor(_height_px - ROW_HEIGHT * _scale), 0)
	local clamped_x = math_min(math_max(px_x, 0), math_floor(_width_px))
	local clamped_y = math_min(math_max(px_y, 0), max_y)
	return clamped_x, clamped_y, clamped_x ~= px_x or clamped_y ~= px_y
end

-- ---- Storage ----

function M.get(bar_name)
	local store = _read_store()
	local entry = store and store[bar_name]
	if _valid_entry(entry) then
		return entry[1], entry[2]
	end
	return nil
end

function M.set(bar_name, x, y)
	if type(bar_name) ~= "string" or bar_name == "" or not _valid_number(x) or not _valid_number(y) then
		return false
	end

	local store = _read_store() or {}
	local entry = store[bar_name]
	if type(entry) == "table" then
		entry[1], entry[2] = x, y
	else
		store[bar_name] = { x, y }
	end
	mod:set(POSITIONS_SETTING_ID, store)
	return true
end

function M.clear(bar_name)
	local store = _read_store()
	if not store or store[bar_name] == nil then
		return false
	end
	store[bar_name] = nil
	mod:set(POSITIONS_SETTING_ID, next(store) ~= nil and store or nil)
	return true
end

function M.rekey(old_name, new_name)
	local store = _read_store()
	if not store or store[old_name] == nil or type(new_name) ~= "string" or new_name == "" then
		return
	end
	store[new_name] = store[old_name]
	store[old_name] = nil
	mod:set(POSITIONS_SETTING_ID, store)
end

function M.clear_all()
	mod:set(POSITIONS_SETTING_ID, nil)
end

-- Drops entries for unknown bars and malformed entries; returns the number removed.
function M.sanitize(known_bars)
	local saved = mod:get(POSITIONS_SETTING_ID)
	if saved == nil then
		return 0
	end
	if type(saved) ~= "table" then
		mod:set(POSITIONS_SETTING_ID, nil)
		return 1
	end

	local removed = 0
	for bar_name, entry in pairs(saved) do
		if not known_bars[bar_name] or not _valid_entry(entry) then
			saved[bar_name] = nil
			removed = removed + 1
		end
	end
	if removed > 0 then
		mod:set(POSITIONS_SETTING_ID, next(saved) ~= nil and saved or nil)
	end
	return removed
end

-- ---- Placement ----

-- Effective UI position (custom first, then slot default); nil when the bar has never been placed.
function M.resolve(bar_name, growth)
	local x, y = M.get(bar_name)
	if x then
		return x, y, true
	end

	local slot = _slot_for(bar_name)
	if not slot then
		return nil
	end

	x, y = Definitions.default_position(slot, growth)
	return x, y, false
end

function M.default_px(bar_name, growth)
	local slot = _slot_for(bar_name)
	if not slot then
		return nil
	end
	return M.ui_to_px(Definitions.default_position(slot, growth))
end

-- bar_views: array of { name = string, count = number }. Returns a localized risk phrase or nil.
function M.describe_risks(bar_name, growth, x, y, buff_count, bar_views)
	local left, right, top, bottom = _bounds(x, y, growth, buff_count)
	local width_ui = _width_px / _scale
	local height_ui = _height_px / _scale

	local edge_count = 0
	if left < 0 then
		edge_count = edge_count + 1
		_edges_scratch[edge_count] = L.EDGE_LEFT
	end
	if right > width_ui then
		edge_count = edge_count + 1
		_edges_scratch[edge_count] = L.EDGE_RIGHT
	end
	if top < -height_ui then
		edge_count = edge_count + 1
		_edges_scratch[edge_count] = L.EDGE_TOP
	end
	if bottom > 0 then
		edge_count = edge_count + 1
		_edges_scratch[edge_count] = L.EDGE_BOTTOM
	end

	local edges_text = nil
	if edge_count > 0 then
		edges_text = mod:localize("gbm_pos_risk_edges", table_concat(_edges_scratch, L.LIST_SEPARATOR, 1, edge_count))
	end
	for i = 1, edge_count do
		_edges_scratch[i] = nil
	end

	local overlap_names = nil
	if type(bar_views) == "table" then
		for i = 1, #bar_views do
			local view = bar_views[i]
			local other = view.name
			if other ~= bar_name and (view.count or 0) > 0 and mod.is_bar_active(other) then
				local other_growth = mod.get_bar_growth(other)
				local other_x, other_y = M.resolve(other, other_growth)
				if other_x then
					local o_left, o_right, o_top, o_bottom = _bounds(other_x, other_y, other_growth, view.count)
					if left < o_right and o_left < right and top < o_bottom and o_top < bottom then
						local tag = "[" .. other .. "]"
						overlap_names = overlap_names and (overlap_names .. L.LIST_SEPARATOR .. tag) or tag
					end
				end
			end
		end
	end

	local overlap_text = overlap_names and mod:localize("gbm_pos_risk_overlap", overlap_names) or nil

	if edges_text and overlap_text then
		return edges_text .. L.RISK_JOIN .. overlap_text
	end
	return edges_text or overlap_text
end

return M
