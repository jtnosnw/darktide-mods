local mod = get_mod("gelatos_buff_manager")

local FALLBACK_MAX_BUFFS_PER_BAR = 20

local M = {}

function M.max_buffs_per_bar()
	local value = mod._gbm_max_buffs
	if type(value) ~= "number" then
		mod:info("Gelato's Buff Manager: the live per-bar icon limit isn't set yet; using 20 informationally.")
		return FALLBACK_MAX_BUFFS_PER_BAR
	end
	return value
end

return M
