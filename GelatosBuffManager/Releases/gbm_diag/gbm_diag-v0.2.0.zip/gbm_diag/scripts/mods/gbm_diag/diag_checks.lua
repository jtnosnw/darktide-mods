local mod = get_mod("gbm_diag")

local GBM_CLASSIFIER_PATH = "gelatos_buff_manager/scripts/mods/gelatos_buff_manager/classification/buff_classifier"
local GBM_DEFINITIONS_PATH = "gelatos_buff_manager/scripts/mods/gelatos_buff_manager/hud/hud_element_buff_bar_definitions"
local PLAYER_BUFFS_SETTINGS_PATH = "scripts/ui/hud/elements/player_buffs/hud_element_player_buffs_settings"
local WORKSPACE_SETTINGS_PATH = "scripts/settings/ui/ui_workspace_settings"
local DEFAULT_CANVAS = { 1920, 1080 }
local DEFAULT_ICON_WIDTH = 38
local DEFAULT_SPACING = 42
local GROWTH_LABELS = { left_right = "left to right", center = "centered", right_left = "right to left" }
local GBM_BAR_PREFIX = "GBMHudElementBuffBar"
local VANILLA_BUFFS_CLASS = "HudElementPlayerBuffs"
local VANILLA_BUFFS_PACKAGE = "packages/ui/hud/player_buffs/player_buffs"
local BAR_SOFT_LIMIT = 6
local BAR_HARD_LIMIT = 10
local SLOT_COLLISION_FROM = 15
local OTHER_PREFIX_TOP = 15
local LIVE_BUFF_LIMIT = 60

local NON_TEMPLATE_KEYS = { PREDICTED = true, NON_PREDICTED = true }
local NAME_SUFFIXES = { "_parent$", "_child$", "_proc$" }
local VALID_PRIORITIES = { [0] = true, [1] = true, [2] = true }
local VALID_GROWTH = { center = true, right_left = true, left_right = true }
local STALE_SETTING_IDS = { "buffs_catalog", "nav_icon_scale", "max_buffs_per_bar" }
local KNOWN_CONFLICT_MODS = { "better_buff_management", "BuffStackHUD" }

local VANILLA_BUFF_METHODS = {
	"init", "draw", "event_player_buff_added", "event_player_buff_stack_added",
	"_sync_current_active_buffs", "_update_buffs", "_update_buff_alignments",
	"_get_available_widget", "_return_widget",
}
local UIHUD_METHODS = { "init", "_add_element" }
local UIMANAGER_METHODS = { "using_input", "create_player_hud", "destroy_player_hud" }
local ACTIVE_ENTRY_FIELDS = { buff_name = "string", activated_time = "number", start_index = "number" }
local IMGUI_FUNCTIONS = {
	"begin_child_window", "begin_combo", "begin_tool_tip", "begin_window", "button", "checkbox",
	"close_imgui", "collapsing_header", "combo", "dummy", "end_child_window", "end_combo",
	"end_tool_tip", "end_window", "get_window_size", "ided_input_text", "image_button",
	"input_text", "is_item_hovered", "open_imgui", "pop_id", "pop_item_width", "push_id",
	"push_item_width", "same_line", "selectable", "separator", "set_item_default_focus",
	"set_next_window_pos", "set_next_window_size", "small_button", "text", "tree_node", "tree_pop",
}
local IMGUI_VIRTUALIZATION_FUNCTIONS = { "get_scroll_y", "get_cursor_pos_y" }
local IMGUI_OPTIONAL_FUNCTIONS = { "get_window_height" }
local IMGUI_DUMP_PATTERNS = { "scroll", "cursor", "clip", "visible", "get_window", "content_region", "item_rect" }

local Checks = {}

-- ---- Shared helpers ----

local function _starts_with(value, prefix)
	return type(value) == "string" and value:sub(1, #prefix) == prefix
end

local function _each_hud_element(hud, callback)
	local elements = hud and hud._elements
	if type(elements) ~= "table" then
		return false
	end
	for name, element in pairs(elements) do
		callback(name, element)
	end
	return true
end

local function _instance_name(instance)
	local template = nil
	if type(instance.template) == "function" then
		local ok, result = pcall(instance.template, instance)
		template = ok and type(result) == "table" and result or nil
	end
	local name = template and template.name
	if type(name) ~= "string" or name == "" then
		local ok, result = false, nil
		if type(instance.template_name) == "function" then
			ok, result = pcall(instance.template_name, instance)
		end
		name = ok and type(result) == "string" and result or nil
	end
	return name, template
end

local function _instance_parent(instance)
	if type(instance.parent_buff_template) ~= "function" then
		return nil
	end
	local ok, result = pcall(instance.parent_buff_template, instance)
	return ok and type(result) == "string" and result ~= "" and result or nil
end

local function _classify(ctx, name)
	local classifier = ctx.classifier
	if classifier == nil then
		return "unclassified", nil
	end
	local ok, category, archetype = pcall(classifier.classify, name)
	if not ok then
		return "unclassified", nil
	end
	return tostring(category), archetype and tostring(archetype) or nil
end

-- ---- Context ----

function Checks.prepare(ctx)
	local U = ctx.U
	local gbm = ctx.gbm

	if gbm then
		local ok, classifier = pcall(mod.io_dofile, mod, GBM_CLASSIFIER_PATH)
		if ok and type(classifier) == "table" and type(classifier.classify) == "function" then
			ctx.classifier = classifier
		end
	end

	local settings = {}
	if gbm then
		settings.buffs_data = U.gbm_get(gbm, "buffs_data")
		settings.bars = U.gbm_get(gbm, "bars")
		settings.active_states = U.gbm_get(gbm, "bar_active_states")
		settings.growth = U.gbm_get(gbm, "gbm_bar_growth")
		settings.slots = U.gbm_get(gbm, "gbm_bar_slots")
		settings.priorities = U.gbm_get(gbm, "gbm_buff_priorities")
		settings.default_bar = U.gbm_get(gbm, "default_buff_bar_enabled")
	end
	ctx.settings = settings

	local bar_set = {}
	if type(settings.bars) == "table" then
		for _, bar_name in ipairs(settings.bars) do
			if U.nonempty(bar_name) then
				bar_set[bar_name] = true
			end
		end
	end
	ctx.bar_set = bar_set

	local filters = {}
	local hidden_counts = {}
	ctx.hidden_counts = hidden_counts
	if type(settings.buffs_data) == "table" then
		for key, data in pairs(settings.buffs_data) do
			if type(data) == "table" and data.is_hidden == true and U.nonempty(data.bar_name) then
				hidden_counts[data.bar_name] = (hidden_counts[data.bar_name] or 0) + 1
			end
			if type(data) == "table" and U.nonempty(data.bar_name) and bar_set[data.bar_name] and data.is_hidden ~= true then
				local name = U.nonempty(data.name) and data.name or key
				local filter = filters[data.bar_name]
				if filter == nil then
					filter = {}
					filters[data.bar_name] = filter
				end
				filter[name] = true
			end
		end
	end
	ctx.filters = filters

	local element_bars = {}
	local expected = {}
	local active_states = settings.active_states
	for bar_name in pairs(filters) do
		local element_name = GBM_BAR_PREFIX .. "_" .. U.pascal(bar_name)
		element_bars[element_name] = bar_name
		local state = type(active_states) == "table" and active_states[bar_name] or nil
		if state == nil or state == true then
			expected[element_name] = true
		end
	end
	ctx.element_bars = element_bars
	ctx.expected_element_count = U.count(expected)

	local buff_settings = U.safe_require(PLAYER_BUFFS_SETTINGS_PATH)
	ctx.max_buffs = type(buff_settings) == "table" and type(buff_settings.max_buffs) == "number"
		and buff_settings.max_buffs or nil
	ctx.spacing = type(buff_settings) == "table" and type(buff_settings.horizontal_spacing) == "number"
		and buff_settings.horizontal_spacing or DEFAULT_SPACING
end

-- ---- Catalog index (mirrors GBM's buff_icon_index resolution order) ----

local function _item_icon(item)
	return (type(item.icon) == "string" and item.icon ~= "") or (type(item.hud_icon) == "string" and item.hud_icon ~= "")
end

local function _mark_trait(map, name)
	if type(name) == "string" and name ~= "" then
		map[name] = true
	end
end

local function _index_item(map, item)
	_mark_trait(map, item.trait)
	_mark_trait(map, item.trait_name)
	if type(item.traits) ~= "table" then
		return
	end
	for _, trait in pairs(item.traits) do
		if type(trait) == "string" then
			_mark_trait(map, trait)
		elseif type(trait) == "table" then
			_mark_trait(map, trait.name)
			_mark_trait(map, trait.id)
			_mark_trait(map, trait.trait)
			_mark_trait(map, trait.trait_name)
		end
	end
end

local function _fill_candidates(out, name)
	for i = #out, 1, -1 do
		out[i] = nil
	end
	out[1] = name
	local count = 1
	for i = 1, #NAME_SUFFIXES do
		local stripped = name:gsub(NAME_SUFFIXES[i], "")
		if stripped ~= "" then
			local duplicate = false
			for j = 1, count do
				if out[j] == stripped then
					duplicate = true
					break
				end
			end
			if not duplicate then
				count = count + 1
				out[count] = stripped
			end
		end
	end
	return count
end

local function _resolve(index, template, candidates)
	if template.hide_icon_in_hud then
		return "hidden"
	end
	if type(template.hud_icon) == "string" and template.hud_icon ~= "" then
		return "own"
	end

	local count = _fill_candidates(candidates, template.name)
	local parent_of_child = index.parent_of_child
	for i = 1, count do
		local parent = parent_of_child[candidates[i]]
		if parent then
			return "parent", parent
		end
	end

	local child_name = template.child_buff_template
	if type(child_name) == "string" and child_name ~= "" then
		local child = index.by_name[child_name]
		if child and type(child.hud_icon) == "string" and child.hud_icon ~= "" then
			return "child", child_name
		end
	end

	local traits = index.traits
	for i = 1, count do
		local mark = traits[candidates[i]]
		if mark then
			return mark == "alias" and "alias" or "item"
		end
	end

	return "none"
end

function Checks.build_index(ctx)
	local U = ctx.U
	local templates = U.safe_require("scripts/settings/buff/buff_templates")
	if type(templates) ~= "table" then
		return nil
	end

	local index = {
		by_name = {},
		parent_of_child = {},
		traits = {},
		source = {},
		partner = {},
		scanned = 0,
		non_template_keys = 0,
		key_mismatch = 0,
		items_available = false,
		trait_templates_available = false,
	}
	local by_name = index.by_name
	local parent_of_child = index.parent_of_child

	for key, template in pairs(templates) do
		if NON_TEMPLATE_KEYS[key] then
			index.non_template_keys = index.non_template_keys + 1
		elseif type(template) == "table" and U.nonempty(template.name) then
			local name = template.name
			index.scanned = index.scanned + 1
			by_name[name] = template
			if key ~= name then
				index.key_mismatch = index.key_mismatch + 1
			end
			local child_name = template.child_buff_template
			if U.nonempty(child_name) and U.nonempty(template.hud_icon) then
				local existing = parent_of_child[child_name]
				if existing == nil or name < existing then
					parent_of_child[child_name] = name
				end
			end
		end
	end

	local traits = index.traits
	local master_items = U.safe_require("scripts/backend/master_items")
	local items = master_items and U.call(master_items, "get_cached") or nil
	if type(items) ~= "table" and master_items and type(master_items.get_cached) == "function" then
		local ok, result = pcall(master_items.get_cached)
		items = ok and result or nil
	end
	if type(items) == "table" then
		index.items_available = true
		for item_key, item in pairs(items) do
			if type(item_key) == "string" and type(item) == "table" and _item_icon(item) then
				_index_item(traits, item)
			end
		end
	end

	local trait_templates = U.safe_require("scripts/settings/equipment/weapon_traits/weapon_trait_templates")
	if type(trait_templates) == "table" then
		index.trait_templates_available = true
		local aliases = {}
		for trait_name, trait_template in pairs(trait_templates) do
			if traits[trait_name] and type(trait_template) == "table" and type(trait_template.buffs) == "table" then
				for buff_name in pairs(trait_template.buffs) do
					if U.nonempty(buff_name) and buff_name ~= trait_name then
						aliases[buff_name] = true
					end
				end
			end
		end
		for buff_name in pairs(aliases) do
			if traits[buff_name] == nil then
				traits[buff_name] = "alias"
			end
		end
	end

	local candidates = {}
	local sources, partners = index.source, index.partner
	for name, template in pairs(by_name) do
		local source, partner = _resolve(index, template, candidates)
		sources[name] = source
		partners[name] = partner
	end

	return index
end

-- ---- 0. Screen and bar layout ----

local function _number_pair(value)
	return type(value) == "table" and type(value[1]) == "number" and type(value[2]) == "number"
end

local function _live_background(element)
	local definitions = type(element) == "table" and element._definitions or nil
	local graph = type(definitions) == "table" and definitions.scenegraph_definition or nil
	local node = type(graph) == "table" and graph.background or nil
	if type(node) == "table" and _number_pair(node.position) then
		return node
	end
	return nil
end

local function _built_background(builder, slot, growth)
	if type(builder) ~= "function" then
		return nil
	end
	local ok, graph = pcall(builder, slot, growth)
	local node = ok and type(graph) == "table" and graph.background or nil
	if type(node) == "table" and _number_pair(node.position) then
		return node
	end
	return nil
end

local function _icons_that_fit(growth, anchor_x, canvas_width, icon_width, spacing)
	local room
	if growth == "center" then
		room = 2 * math.min(anchor_x, canvas_width - anchor_x)
	elseif growth == "right_left" then
		room = anchor_x
	else
		room = canvas_width - anchor_x
	end
	if room < icon_width or spacing <= 0 then
		return 0
	end
	return math.floor((room - icon_width) / spacing) + 1
end

local function _fmt(value)
	if type(value) ~= "number" then
		return tostring(value)
	end
	if value == math.floor(value) then
		return ("%d"):format(value)
	end
	return ("%.2f"):format(value)
end

function Checks.layout(ctx)
	local R, U = ctx.report, ctx.U
	R:section("0. Screen and bar layout")

	local lookup = U.global("RESOLUTION_LOOKUP")
	local ui_scale = type(lookup) == "table" and type(lookup.scale) == "number" and lookup.scale or nil
	if type(lookup) == "table" and type(lookup.width) == "number" and type(lookup.height) == "number" then
		R:info(("screen resolution: %sx%s, UI scale %s"):format(_fmt(lookup.width), _fmt(lookup.height), _fmt(ui_scale)))
	else
		R:warn("screen resolution unavailable (RESOLUTION_LOOKUP.width/height missing)")
	end

	local hud = U.current_hud()
	local hud_scale = U.call(hud, "_hud_scale")
	R:info("HUD scale: " .. (type(hud_scale) == "number" and _fmt(hud_scale) or "unavailable"))

	local canvas_width, canvas_height = DEFAULT_CANVAS[1], DEFAULT_CANVAS[2]
	local workspace = U.safe_require(WORKSPACE_SETTINGS_PATH)
	local screen = type(workspace) == "table" and workspace.screen or nil
	if type(screen) == "table" and _number_pair(screen.size) then
		canvas_width, canvas_height = screen.size[1], screen.size[2]
	end
	R:info(("UI canvas: %sx%s units (bar positions below use these units; ~px = units x UI scale)"):format(
		_fmt(canvas_width), _fmt(canvas_height)))

	local gbm = ctx.gbm
	if not gbm then
		R:info("custom bars skipped - Gelato's Buff Manager not loaded")
		return
	end

	local settings = ctx.settings
	R:info("vanilla buff bar: " .. (settings.default_bar == false and "hidden" or "shown") .. " (GBM setting)")

	local definitions = nil
	local ok_defs, loaded = pcall(mod.io_dofile, mod, GBM_DEFINITIONS_PATH)
	if ok_defs and type(loaded) == "table" then
		definitions = loaded
	else
		R:warn("GBM bar position builder unavailable - positions shown only for bars on the HUD")
	end
	local builder = definitions and definitions.build_scenegraph_definition
	local icon_width = definitions and type(definitions.BUFF_NODE_WIDTH) == "number" and definitions.BUFF_NODE_WIDTH
		or DEFAULT_ICON_WIDTH
	local spacing = ctx.spacing or DEFAULT_SPACING
	local max_buffs = ctx.max_buffs

	local live = {}
	local elements = hud and hud._elements
	if type(elements) == "table" then
		for name, element in pairs(elements) do
			if _starts_with(name, GBM_BAR_PREFIX) then
				live[name] = element
			end
		end
	end

	local bars = settings.bars
	local count = 0
	local listed = {}
	local element_owner = {}
	if type(bars) == "table" then
		for _, bar_name in ipairs(bars) do
			if U.nonempty(bar_name) and not listed[bar_name] then
				listed[bar_name] = true
				count = count + 1

				local element_name = GBM_BAR_PREFIX .. "_" .. U.pascal(bar_name)
				local owner = element_owner[element_name]
				element_owner[element_name] = owner or bar_name
				local element = owner == nil and live[element_name] or nil
				local state = type(settings.active_states) == "table" and settings.active_states[bar_name] or nil
				local active_text = (state == nil or state == true) and "yes" or (state == false and "no" or "no (invalid value)")
				local growth = type(settings.growth) == "table" and settings.growth[bar_name] or nil
				if growth ~= "center" and growth ~= "right_left" then
					growth = "left_right"
				end
				local slot = type(settings.slots) == "table" and settings.slots[bar_name] or nil
				if type(slot) ~= "number" then
					slot = nil
				end
				local visible = U.count(ctx.filters[bar_name])
				local hidden = ctx.hidden_counts[bar_name] or 0

				local on_hud
				if owner then
					on_hud = ("no (same HUD name as '%s')"):format(owner)
				elseif element then
					on_hud = "yes"
				elseif active_text ~= "yes" then
					on_hud = "no (switched off)"
				elseif visible == 0 then
					on_hud = "no (no visible buffs assigned)"
				else
					on_hud = "no (unexpected)"
				end

				local node = _live_background(element)
				local source = "live"
				if node == nil and slot then
					node = _built_background(builder, slot, growth)
					source = "calculated"
				end

				local position_text = "position: none yet (a slot is assigned when the bar first appears)"
				local fit = nil
				if node then
					local x, y = node.position[1], node.position[2]
					local height = _number_pair(node.size) and node.size[2] or 0
					local top = canvas_height + y - height
					local px = ui_scale and (" (~px %s,%s)"):format(_fmt(x * ui_scale), _fmt(top * ui_scale)) or ""
					position_text = ("anchor x %s, y %s from bottom | top-left %s,%s%s [%s]"):format(
						_fmt(x), _fmt(y), _fmt(x), _fmt(top), px, source)
					fit = _icons_that_fit(growth, x, canvas_width, icon_width, spacing)
				end

				local fit_text = fit and ("fits %d of %s icons"):format(fit, tostring(max_buffs or "?")) or "fit unknown"
				R:line(("[BAR] '%s' | active: %s | on HUD: %s | slot: %s | growth: %s | %s | buffs: %d visible, %d hidden | %s"):format(
					bar_name, active_text, on_hud, tostring(slot or "none"), GROWTH_LABELS[growth], position_text,
					visible, hidden, fit_text))

				if on_hud == "no (unexpected)" then
					R:warn(("bar '%s' should be on the HUD but is not - a HUD rebuild may be pending"):format(bar_name))
				end
				if fit and max_buffs and fit < max_buffs and visible > fit then
					R:warn(("bar '%s' can run off-screen if more than %d of its %d buffs are active at once"):format(
						bar_name, fit, visible))
				end
			end
		end
	end

	if count == 0 then
		R:info("no custom buff bars created")
	else
		R:info(("%d custom buff bar(s)"):format(count))
	end

	for name in pairs(live) do
		if element_owner[name] == nil then
			R:warn("HUD shows GBM bar element " .. tostring(name) .. " that has no saved bar")
		end
	end
end

-- ---- 1. Patch compatibility ----

local function _check_module(R, U, path, validator)
	local module = U.safe_require(path)
	if module == nil then
		R:fail("require " .. path .. " - failed to load")
		return nil
	end
	if validator then
		local ok, detail = validator(module)
		R:expect(ok, "require " .. path, detail)
	else
		R:ok("require " .. path)
	end
	return module
end

local function _check_methods(R, class_table, class_name, methods)
	for i = 1, #methods do
		local method = methods[i]
		R:expect(type(class_table) == "table" and type(class_table[method]) == "function",
			class_name .. "." .. method, "missing")
	end
end

function Checks.compat(ctx)
	local R, U = ctx.report, ctx.U
	R:section("1. Patch compatibility")

	local classes = U.global("CLASSES")
	R:expect(type(classes) == "table", "CLASSES registry", "missing")
	R:expect(type(U.global("class")) == "function", "class() global", "missing")
	R:expect(type(U.global("settings")) == "function", "settings() global", "missing")
	classes = type(classes) == "table" and classes or {}

	local vanilla_class = classes[VANILLA_BUFFS_CLASS]
	R:expect(type(vanilla_class) == "table", "class " .. VANILLA_BUFFS_CLASS, "missing")
	_check_module(R, U, "scripts/ui/hud/elements/player_buffs/hud_element_player_buffs_polling")
	_check_methods(R, vanilla_class, VANILLA_BUFFS_CLASS, VANILLA_BUFF_METHODS)

	_check_module(R, U, "scripts/ui/hud/elements/player_buffs/hud_element_player_buffs_definitions", function(m)
		if type(m) ~= "table" then
			return false, "not a table"
		end
		for _, field in ipairs({ "scenegraph_definition", "widget_definitions", "buff_widget_definition" }) do
			if type(m[field]) ~= "table" then
				return false, field .. " missing"
			end
		end
		return true
	end)

	local buff_settings = _check_module(R, U, PLAYER_BUFFS_SETTINGS_PATH,
		function(m)
			if type(m) ~= "table" or type(m.max_buffs) ~= "number" then
				return false, "max_buffs missing"
			end
			if type(m.horizontal_spacing) ~= "number" then
				return false, "horizontal_spacing missing"
			end
			return true
		end)
	if type(buff_settings) == "table" and type(buff_settings.max_buffs) == "number" then
		R:info(("vanilla per-bar icon limit: %s (GBM follows the live value; see section 0 for screen fit)"):format(
			tostring(buff_settings.max_buffs)))
	end

	_check_module(R, U, "scripts/ui/hud/hud_elements_player", function(m)
		if type(m) ~= "table" then
			return false, "not a table"
		end
		for _, definition in pairs(m) do
			if type(definition) == "table" and definition.class_name == VANILLA_BUFFS_CLASS then
				if definition.package ~= VANILLA_BUFFS_PACKAGE then
					return false, "buff bar package changed to " .. tostring(definition.package)
				end
				return true
			end
		end
		return false, VANILLA_BUFFS_CLASS .. " definition missing"
	end)

	_check_module(R, U, "scripts/settings/buff/buff_settings", function(m)
		if type(m) ~= "table" or type(m.buff_categories) ~= "table" or type(m.buff_category_order) ~= "table" then
			return false, "buff_categories / buff_category_order missing"
		end
		if m.buff_categories.generic == nil then
			return false, "buff_categories.generic missing"
		end
		return true
	end)

	_check_module(R, U, "scripts/settings/buff/buff_templates", function(m)
		return type(m) == "table" and next(m) ~= nil, "empty"
	end)

	_check_module(R, U, "scripts/backend/master_items", function(m)
		return U.has_fn(m, "get_cached"), "get_cached missing"
	end)

	if U.safe_require("scripts/settings/equipment/weapon_traits/weapon_trait_templates") then
		R:ok("require scripts/settings/equipment/weapon_traits/weapon_trait_templates")
	else
		R:warn("require scripts/settings/equipment/weapon_traits/weapon_trait_templates - failed; trait-name icon aliases will be skipped")
	end

	local hud_settings = _check_module(R, U, "scripts/settings/ui/ui_hud_settings", function(m)
		return U.has_fn(m, "get_hud_color"), "get_hud_color missing"
	end)
	local layers = type(hud_settings) == "table" and hud_settings.element_draw_layers or nil
	local layer = type(layers) == "table" and layers[VANILLA_BUFFS_CLASS] or nil
	R:info("vanilla buff bar draw layer: " .. tostring(layer) .. " (GBM uses 100)")

	_check_module(R, U, "scripts/settings/ui/ui_workspace_settings", function(m)
		return type(m) == "table", "not a table"
	end)

	_check_methods(R, classes.UIHud, "UIHud", UIHUD_METHODS)
	_check_methods(R, classes.UIManager, "UIManager", UIMANAGER_METHODS)

	local hud = U.current_hud()
	R:expect(hud ~= nil, "Managers.ui._hud (live HUD)", "missing")
	if hud then
		R:expect(type(hud._element_definitions) == "table", "UIHud._element_definitions", "missing")
		R:expect(type(hud._visibility_groups) == "table", "UIHud._visibility_groups", "missing")
		R:expect(type(hud._elements) == "table", "UIHud._elements", "missing")
	end

	local player_manager = Managers and Managers.player
	R:expect(U.has_fn(player_manager, "local_player"), "Managers.player:local_player", "missing")
	local player = U.call(player_manager, "local_player_safe", 1) or U.call(player_manager, "local_player", 1)
	R:expect(U.has_fn(player, "peer_id") and U.has_fn(player, "local_player_id"),
		"player:peer_id / player:local_player_id", "missing")

	local game_mode = Managers and Managers.state and Managers.state.game_mode
	R:expect(U.has_fn(game_mode, "game_mode_name"), "game_mode:game_mode_name", "missing")

	local lookup = U.global("RESOLUTION_LOOKUP")
	R:expect(type(lookup) == "table" and type(lookup.scale) == "number", "RESOLUTION_LOOKUP.scale", "missing")

	local color = U.global("Color")
	R:expect(U.has_fn(color, "ui_grey_medium"), "Color.ui_grey_medium", "missing")
	R:expect(type(table.enum) == "function", "table.enum", "missing")

	local imgui = U.global("Imgui")
	local missing = {}
	for i = 1, #IMGUI_FUNCTIONS do
		if not U.has_fn(imgui, IMGUI_FUNCTIONS[i]) then
			missing[#missing + 1] = IMGUI_FUNCTIONS[i]
		end
	end
	R:expect(#missing == 0, ("Imgui functions GBM needs (%d)"):format(#IMGUI_FUNCTIONS),
		"missing: " .. table.concat(missing, ", "))

	local missing_virtual = {}
	for i = 1, #IMGUI_VIRTUALIZATION_FUNCTIONS do
		if not U.has_fn(imgui, IMGUI_VIRTUALIZATION_FUNCTIONS[i]) then
			missing_virtual[#missing_virtual + 1] = IMGUI_VIRTUALIZATION_FUNCTIONS[i]
		end
	end
	if #missing_virtual == 0 then
		R:ok("Imgui scroll queries available - GBM UI list virtualization active")
	else
		R:warn("Imgui scroll queries missing (" .. table.concat(missing_virtual, ", ") ..
			") - GBM UI draws every list row while open; no effect in missions")
	end
	for i = 1, #IMGUI_OPTIONAL_FUNCTIONS do
		if not U.has_fn(imgui, IMGUI_OPTIONAL_FUNCTIONS[i]) then
			R:info("Imgui." .. IMGUI_OPTIONAL_FUNCTIONS[i] .. " missing - GBM uses get_window_size instead")
		end
	end

	if type(imgui) == "table" then
		local related = {}
		for name, value in pairs(imgui) do
			if type(name) == "string" and type(value) == "function" then
				for i = 1, #IMGUI_DUMP_PATTERNS do
					if name:find(IMGUI_DUMP_PATTERNS[i], 1, true) then
						related[#related + 1] = name
						break
					end
				end
			end
		end
		table.sort(related)
		R:info(("Imgui scroll/cursor/window-query functions available (%d): %s"):format(
			#related, #related > 0 and table.concat(related, ", ") or "none listed"))
	end

	for _, device_name in ipairs({ "Keyboard", "Mouse" }) do
		local device = U.global(device_name)
		if U.has_fn(device, "button_index") and U.has_fn(device, "button") then
			R:ok(device_name .. ".button_index / button")
		else
			R:warn(device_name .. ".button_index / button missing - GBM window close-on-release degrades")
		end
	end

	local entry_found = false
	_each_hud_element(hud, function(name, element)
		if entry_found or type(element) ~= "table" or type(element._active_buffs_data) ~= "table" then
			return
		end
		local entry = element._active_buffs_data[1]
		if type(entry) ~= "table" then
			return
		end
		entry_found = true
		for field, expected_type in pairs(ACTIVE_ENTRY_FIELDS) do
			R:expect(type(entry[field]) == expected_type, "active buff entry field " .. field,
				"expected " .. expected_type .. ", got " .. type(entry[field]))
		end
		R:info("active buff entry has buff_instance field: " .. tostring(entry.buff_instance ~= nil))
	end)
	if not entry_found then
		R:info("no active buff entries to inspect - trigger a buff and run again to check entry fields")
	end
end

-- ---- 2. Saved assignments vs game ----

function Checks.saved_vs_game(ctx)
	local R, U = ctx.report, ctx.U
	R:section("2. Saved assignments vs game")

	if not ctx.gbm then
		R:info("skipped - Gelato's Buff Manager not loaded")
		return
	end
	local index = ctx.index
	if not index then
		R:fail("skipped - buff templates unavailable")
		return
	end

	local issues = 0
	local buffs_data = ctx.settings.buffs_data
	if type(buffs_data) == "table" then
		local keys = U.sorted_keys(buffs_data)
		for i = 1, #keys do
			local key = keys[i]
			local data = buffs_data[key]
			if type(data) == "table" then
				local name = U.nonempty(data.name) and data.name or key
				local bar_name = tostring(data.bar_name)
				if index.by_name[name] == nil then
					issues = issues + 1
					R:warn(("assigned buff no longer exists in game: %s (bar '%s')"):format(name, bar_name))
				else
					local source = index.source[name]
					if source == "none" or source == "hidden" then
						issues = issues + 1
						R:warn(("assigned buff has no catalog icon (not shown in GBM UI): %s (bar '%s')"):format(name, bar_name))
					end
				end
				if U.nonempty(data.bar_name) and not ctx.bar_set[data.bar_name] then
					issues = issues + 1
					R:warn(("assignment points to a bar that no longer exists: %s -> '%s'"):format(name, bar_name))
				end
			end
		end
	end

	local priorities = ctx.settings.priorities
	if type(priorities) == "table" then
		local keys = U.sorted_keys(priorities)
		for i = 1, #keys do
			if index.by_name[keys[i]] == nil then
				issues = issues + 1
				R:warn("buff priority set on a buff that no longer exists: " .. keys[i])
			end
		end
	end

	local bars = ctx.settings.bars
	if type(bars) == "table" then
		for _, bar_name in ipairs(bars) do
			if U.nonempty(bar_name) and ctx.filters[bar_name] == nil then
				R:info(("bar '%s' has no visible assignments, so it is not added to the HUD"):format(bar_name))
			end
		end
	end

	for _, pair in ipairs({
		{ "bar_active_states", ctx.settings.active_states },
		{ "gbm_bar_growth", ctx.settings.growth },
		{ "gbm_bar_slots", ctx.settings.slots },
	}) do
		if type(pair[2]) == "table" then
			local keys = U.sorted_keys(pair[2])
			for i = 1, #keys do
				if not ctx.bar_set[keys[i]] then
					issues = issues + 1
					R:warn(("%s has an entry for a bar that no longer exists: '%s'"):format(pair[1], keys[i]))
				end
			end
		end
	end

	if issues == 0 then
		R:ok("all saved assignments, priorities and bar settings match existing buffs and bars")
	end
end

-- ---- 3. Catalog health and parent/child check ----

local function _top_prefixes(counts, limit)
	local list = {}
	for prefix, count in pairs(counts) do
		list[#list + 1] = { prefix = prefix, count = count }
	end
	table.sort(list, function(a, b)
		if a.count ~= b.count then
			return a.count > b.count
		end
		return a.prefix < b.prefix
	end)
	local parts = {}
	for i = 1, math.min(limit, #list) do
		parts[i] = ("%s_ (%d)"):format(list[i].prefix, list[i].count)
	end
	return parts, #list
end

function Checks.catalog(ctx)
	local R, U = ctx.report, ctx.U
	R:section("3. Catalog health and parent/child check")

	local index = ctx.index
	if not index then
		R:fail("buff templates unavailable - catalog cannot be built")
		return
	end

	R:info(("templates scanned: %d, non-template keys: %d"):format(index.scanned, index.non_template_keys))
	if index.key_mismatch > 0 then
		R:warn(("%d template(s) stored under a key different from their name (catalog keys by name)"):format(
			index.key_mismatch))
	else
		R:ok("every template key matches its name")
	end
	R:expect(index.items_available, "master items available for weapon icons", "unavailable - blessing icons missing")
	if not index.trait_templates_available then
		R:warn("weapon trait templates unavailable - trait-name aliases skipped")
	end

	local totals = { own = 0, parent = 0, child = 0, item = 0, alias = 0, none = 0, hidden = 0 }
	local per_class = {}
	local other_prefixes = {}
	local list_a, list_b = {}, {}

	local partners = index.partner
	for name, source in pairs(index.source) do
		local partner = partners[name]
		totals[source] = (totals[source] or 0) + 1
		if source ~= "none" and source ~= "hidden" then
			local category, archetype = _classify(ctx, name)
			local label = archetype or category
			per_class[label] = (per_class[label] or 0) + 1
			if category == "other" then
				local prefix = name:match("^([^_]+)") or name
				other_prefixes[prefix] = (other_prefixes[prefix] or 0) + 1
			end
			if source == "parent" then
				local parent = index.by_name[partner]
				local hidden_note = parent and parent.hide_icon_in_hud and " [parent hides icon]" or ""
				list_a[#list_a + 1] = ("[A] %s <- drawn parent: %s (%s)%s"):format(
					name, tostring(partner), archetype or category, hidden_note)
			elseif source == "child" then
				list_b[#list_b + 1] = ("[B] %s -> drawn child: %s (%s)"):format(
					name, tostring(partner), archetype or category)
			end
		end
	end

	local in_catalog = totals.own + totals.parent + totals.child + totals.item + totals.alias
	R:info(("catalog rows: %d (own icon %d, via parent %d, via child %d, via weapon item %d, via trait alias %d)"):format(
		in_catalog, totals.own, totals.parent, totals.child, totals.item, totals.alias))
	R:info(("excluded: %d without any icon, %d with hide_icon_in_hud"):format(totals.none, totals.hidden))

	local class_keys = U.sorted_keys(per_class)
	local class_parts = {}
	for i = 1, #class_keys do
		class_parts[i] = ("%s %d"):format(class_keys[i], per_class[class_keys[i]])
	end
	R:info("rows per class/category: " .. table.concat(class_parts, ", "))
	if ctx.classifier == nil then
		R:warn("GBM classifier unavailable - class breakdown skipped")
	end

	local prefixes, prefix_total = _top_prefixes(other_prefixes, OTHER_PREFIX_TOP)
	if prefix_total > 0 then
		R:info(("'other' rows use %d name prefix(es); most common: %s"):format(prefix_total, table.concat(prefixes, ", ")))
		R:line("      A new class or naming scheme shows up here as a large unfamiliar prefix.")
	end

	table.sort(list_a)
	table.sort(list_b)

	R:line(("List A (hidden child rows - assigning them shows nothing; fixed by v0.31.1): %d"):format(#list_a))
	for i = 1, #list_a do
		R:line(list_a[i])
	end
	R:line(("List B (icon-less parent rows - work only if the drawn child reports its parent; needs in-game test): %d"):format(#list_b))
	for i = 1, #list_b do
		R:line(list_b[i])
	end
end

-- ---- 4. Settings integrity ----

local function _check_map(R, U, setting_id, value, validator, fallback_text)
	if value == nil then
		R:ok(setting_id .. " (not set)")
		return
	end
	if type(value) ~= "table" then
		R:fail(("%s is a %s, not a table - %s"):format(setting_id, type(value), fallback_text))
		return
	end
	local bad = 0
	local keys = U.sorted_keys(value)
	for i = 1, #keys do
		local key = keys[i]
		local item = value[key]
		if item == nil then
			local numeric = tonumber(key)
			item = numeric and value[numeric] or nil
		end
		local ok, detail = validator(key, item)
		if not ok then
			bad = bad + 1
			local shown = type(item) == "table" and "{...}" or tostring(item)
			R:warn(("%s['%s'] = %s: %s - %s"):format(setting_id, key, shown, detail, fallback_text))
		end
	end
	if bad == 0 then
		R:ok(("%s (%d entries)"):format(setting_id, #keys))
	end
end

local function _check_widgets(R, U, gbm, widgets)
	if type(widgets) ~= "table" then
		return
	end
	for _, widget in ipairs(widgets) do
		if type(widget) == "table" then
			local id = widget.setting_id
			local kind = widget.type
			if U.nonempty(id) and kind ~= "group" then
				local value = U.gbm_get(gbm, id)
				local ok, detail = true, nil
				if value == nil then
					ok = true
				elseif kind == "checkbox" then
					ok, detail = type(value) == "boolean", "expected true/false"
				elseif kind == "keybind" then
					ok, detail = type(value) == "table", "expected a key list"
					if ok then
						local keys = {}
						for _, key in ipairs(value) do
							keys[#keys + 1] = tostring(key)
						end
						value = #keys > 0 and table.concat(keys, " + ") or "unbound"
					end
				elseif kind == "numeric" then
					local range = widget.range
					ok = type(value) == "number" and (type(range) ~= "table" or (value >= range[1] and value <= range[2]))
					detail = "expected a number in range"
				elseif kind == "dropdown" then
					ok, detail = false, "not a listed option"
					for _, option in ipairs(widget.options or {}) do
						if type(option) == "table" and option.value == value then
							ok = true
							break
						end
					end
				end
				if ok then
					R:ok(("option %s = %s"):format(id, value == nil and "default" or tostring(value)))
				else
					R:warn(("option %s = %s: %s - GBM uses the default (%s)"):format(
						id, tostring(value), detail, tostring(widget.default_value)))
				end
			end
			_check_widgets(R, U, gbm, widget.sub_widgets)
		end
	end
end

function Checks.integrity(ctx)
	local R, U = ctx.report, ctx.U
	R:section("4. Settings integrity")

	local gbm = ctx.gbm
	if not gbm then
		R:info("skipped - Gelato's Buff Manager not loaded")
		return
	end

	local s = ctx.settings
	local bars = s.bars
	if bars == nil then
		R:ok("bars (no bars saved)")
	elseif type(bars) ~= "table" then
		R:fail("bars is a " .. type(bars) .. ", not a list - GBM shows no custom bars")
	else
		local seen, element_owner = {}, {}
		local issues = 0
		for i, bar_name in ipairs(bars) do
			if not U.nonempty(bar_name) then
				issues = issues + 1
				R:warn(("bars[%d] = %s: not a bar name - entry is unusable"):format(i, tostring(bar_name)))
			elseif seen[bar_name] then
				issues = issues + 1
				R:warn(("bars lists '%s' twice - two HUD elements would compete for one name"):format(bar_name))
			else
				seen[bar_name] = true
				local element_name = U.pascal(bar_name)
				local other = element_owner[element_name]
				if other then
					issues = issues + 1
					R:warn(("bars '%s' and '%s' map to the same HUD element name - only one will show"):format(other, bar_name))
				else
					element_owner[element_name] = bar_name
				end
			end
		end
		local count = U.count(seen)
		if count > BAR_HARD_LIMIT then
			issues = issues + 1
			R:warn(("%d bars saved, above GBM's hard cap of %d"):format(count, BAR_HARD_LIMIT))
		elseif count >= BAR_SOFT_LIMIT then
			R:info(("%d bars saved (GBM soft warning starts at %d)"):format(count, BAR_SOFT_LIMIT))
		end
		if #bars ~= U.count(bars) then
			issues = issues + 1
			R:warn("bars has non-list keys - GBM ignores them")
		end
		if issues == 0 then
			R:ok(("bars (%d)"):format(count))
		end
	end

	_check_map(R, U, "buffs_data", s.buffs_data, function(key, data)
		if type(data) ~= "table" then
			return false, "not a table"
		end
		if data.name ~= nil and data.name ~= key then
			return false, "name field does not match key"
		end
		if data.bar_name ~= nil and type(data.bar_name) ~= "string" then
			return false, "bar_name is not text"
		end
		if data.is_hidden ~= nil and type(data.is_hidden) ~= "boolean" then
			return false, "is_hidden is not true/false"
		end
		return true
	end, "entry is ignored or behaves unpredictably")

	_check_map(R, U, "bar_active_states", s.active_states, function(key, value)
		return type(value) == "boolean", "expected true/false"
	end, "GBM treats the bar as inactive")

	_check_map(R, U, "gbm_bar_growth", s.growth, function(key, value)
		return VALID_GROWTH[value] == true, "unknown growth mode"
	end, "GBM falls back to left-to-right")

	local slot_owner = {}
	_check_map(R, U, "gbm_bar_slots", s.slots, function(key, value)
		if type(value) ~= "number" or value < 1 or value ~= math.floor(value) then
			return false, "expected a whole number of 1 or more"
		end
		local other = slot_owner[value]
		if other then
			return false, "same slot as bar '" .. other .. "' (bars overlap on screen)"
		end
		slot_owner[value] = key
		if value >= SLOT_COLLISION_FROM then
			return false, "slot this high may overlap other HUD elements at 1080p"
		end
		return true
	end, "GBM ignores the entry and assigns a new slot where needed")

	_check_map(R, U, "gbm_buff_priorities", s.priorities, function(key, value)
		return VALID_PRIORITIES[value] == true, "expected 0, 1 or 2"
	end, "GBM coerces it to default priority")

	local options = U.call(gbm, "get_internal_data", "options")
	if type(options) == "table" then
		_check_widgets(R, U, gbm, options.widgets)
	else
		R:warn("GBM option definitions unavailable - option values not checked")
	end

	for i = 1, #STALE_SETTING_IDS do
		local id = STALE_SETTING_IDS[i]
		if U.gbm_get(gbm, id) ~= nil then
			R:info("obsolete setting '" .. id .. "' still saved - GBM removes it on next load")
		end
	end
end

-- ---- 5. Conflict check ----

function Checks.conflicts(ctx)
	local R, U = ctx.report, ctx.U
	R:section("5. Conflict check")

	local found = 0
	for i = 1, #KNOWN_CONFLICT_MODS do
		local name = KNOWN_CONFLICT_MODS[i]
		local ok, other = pcall(get_mod, name)
		if ok and other then
			found = found + 1
			R:warn(("buff bar mod '%s' is loaded (enabled: %s)"):format(name, tostring(U.call(other, "is_enabled"))))
		end
	end

	local classes = U.global("CLASSES")
	local vanilla_class = type(classes) == "table" and classes[VANILLA_BUFFS_CLASS] or nil
	if vanilla_class then
		local names = {}
		for class_name, class_table in pairs(classes) do
			if type(class_table) == "table" and rawget(class_table, "super") == vanilla_class
				and not _starts_with(class_name, GBM_BAR_PREFIX) then
				names[#names + 1] = tostring(class_name)
			end
		end
		table.sort(names)
		for i = 1, #names do
			found = found + 1
			R:warn("another mod extends the vanilla buff bar: class " .. names[i])
		end
	else
		R:info("vanilla buff bar class unavailable - subclass scan skipped")
	end

	local hud = U.current_hud()
	if hud and type(hud._elements) == "table" and ctx.gbm then
		local present = hud._elements[VANILLA_BUFFS_CLASS] ~= nil
		local wanted = ctx.settings.default_bar ~= false
		if present == wanted then
			R:ok(("vanilla buff bar %s, matching GBM's setting"):format(present and "shown" or "hidden"))
		else
			found = found + 1
			R:warn(("vanilla buff bar is %s but GBM's setting says %s - another mod may be adding or removing it"):format(
				present and "shown" or "hidden", wanted and "shown" or "hidden"))
		end
	end

	if found == 0 then
		R:ok("no known conflicting buff bar mods detected")
	end
end

-- ---- 6. Live buff snapshot ----

local function _entry_status(element, instance, name)
	local entries = type(element) == "table" and element._active_buffs_data or nil
	if type(entries) ~= "table" then
		return nil
	end
	for i = 1, #entries do
		local entry = entries[i]
		if type(entry) == "table" then
			local match = entry.buff_instance == instance
			if entry.buff_instance == nil then
				match = entry.buff_name == name
			end
			if match then
				if entry.widget ~= nil then
					return "shown"
				elseif entry.remove then
					return "expiring"
				elseif entry.show == false then
					return "inactive"
				end
				return "no slot"
			end
		end
	end
	return "absent"
end

function Checks.live(ctx)
	local R, U = ctx.report, ctx.U
	R:section("6. Live buff snapshot")

	local player_manager = Managers and Managers.player
	local player = U.call(player_manager, "local_player_safe", 1) or U.call(player_manager, "local_player", 1)
	local unit = type(player) == "table" and player.player_unit or nil
	local script_unit = U.global("ScriptUnit")
	local buff_extension = nil
	if unit and script_unit and type(script_unit.has_extension) == "function" then
		local ok, extension = pcall(script_unit.has_extension, unit, "buff_system")
		buff_extension = ok and extension or nil
	end
	if not buff_extension then
		R:warn("player buff extension unavailable - snapshot skipped")
		return
	end

	local buffs = U.call(buff_extension, "buffs")
	if type(buffs) ~= "table" then
		buffs = buff_extension._buffs
	end
	if type(buffs) ~= "table" then
		R:warn("player buff list unavailable - snapshot skipped")
		return
	end

	local hud = U.current_hud()
	local gbm_elements = {}
	local vanilla_element = nil
	_each_hud_element(hud, function(name, element)
		if _starts_with(name, GBM_BAR_PREFIX) then
			gbm_elements[#gbm_elements + 1] = { name = name, element = element, bar = ctx.element_bars[name] }
		elseif name == VANILLA_BUFFS_CLASS then
			vanilla_element = element
		end
	end)
	table.sort(gbm_elements, function(a, b)
		return a.name < b.name
	end)

	local instances = {}
	for _, instance in pairs(buffs) do
		if type(instance) == "table" then
			instances[#instances + 1] = instance
		end
	end
	R:info(("%d active buff instance(s); %d GBM bar element(s) on the HUD; vanilla bar %s"):format(
		#instances, #gbm_elements, vanilla_element and "present" or "absent"))
	if #instances == 0 then
		R:line("      Trigger some talents or blessings, then run /gbm_diag again for a useful snapshot.")
	end

	local missing_api = 0
	local child_only = 0
	for i = 1, math.min(#instances, LIVE_BUFF_LIMIT) do
		local instance = instances[i]
		local name, template = _instance_name(instance)
		if name == nil then
			missing_api = missing_api + 1
		else
			local parent = _instance_parent(instance)
			local child = template and U.nonempty(template.child_buff_template) and template.child_buff_template or nil
			local has_hud = U.call(instance, "has_hud")
			local matches = {}
			for j = 1, #gbm_elements do
				local bar_name = gbm_elements[j].bar
				local filter = bar_name and ctx.filters[bar_name]
				if filter then
					local how = nil
					if filter[name] then
						how = "own"
					elseif parent and filter[parent] then
						how = "parent"
					elseif child and filter[child] then
						how = "child-only"
						child_only = child_only + 1
					end
					if how then
						local status = _entry_status(gbm_elements[j].element, instance, name)
						matches[#matches + 1] = ("%s[%s, %s]"):format(bar_name, how, tostring(status))
					end
				end
			end
			local vanilla_status = vanilla_element and _entry_status(vanilla_element, instance, name) or "n/a"
			R:line(("[L] %s | parent: %s | child: %s | has_hud: %s | GBM: %s | vanilla: %s"):format(
				name, parent or "-", child or "-", tostring(has_hud),
				#matches > 0 and table.concat(matches, " ") or "-", tostring(vanilla_status)))
		end
	end
	if #instances > LIVE_BUFF_LIMIT then
		R:info(("%d further buff instance(s) not listed"):format(#instances - LIVE_BUFF_LIMIT))
	end

	R:expect(missing_api == 0, "every live buff reports its template name",
		("%d instance(s) without template()/template_name()"):format(missing_api))
	if child_only > 0 then
		R:warn(("%d bar match(es) only via the child name - v0.31.0 does not show these (fixed in v0.31.1)"):format(child_only))
	end
	R:line(("      Status: shown = on screen, inactive = the game is hiding it right now (e.g. a proc that is not active), expiring = being removed, no slot = over the %s-icon limit, absent = not tracked by that bar."):format(
		tostring(ctx.max_buffs or "?")))
end

return Checks
