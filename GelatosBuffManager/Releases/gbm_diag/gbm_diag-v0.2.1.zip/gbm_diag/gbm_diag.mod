return {
	run = function()
		fassert(rawget(_G, "new_mod"), "`gbm_diag` requires the Darktide Mod Framework.")

		new_mod("gbm_diag", {
			mod_script = "gbm_diag/scripts/mods/gbm_diag/gbm_diag",
			mod_data = "gbm_diag/scripts/mods/gbm_diag/gbm_diag_data",
			mod_localization = "gbm_diag/scripts/mods/gbm_diag/gbm_diag_localization",
		})
	end,
	packages = {},
}
