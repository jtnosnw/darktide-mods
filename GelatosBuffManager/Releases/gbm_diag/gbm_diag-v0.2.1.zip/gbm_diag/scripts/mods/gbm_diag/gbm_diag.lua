local mod = get_mod("gbm_diag")

mod.version = mod:io_dofile("gbm_diag/scripts/mods/gbm_diag/gbm_diag_version")

local RUNNER_PATH = "gbm_diag/scripts/mods/gbm_diag/diag_runner"
local PSYKHANIUM_GAME_MODE = "shooting_range"
local PSYKHANIUM_MISSION = "tg_shooting_range"

local L = {
	cmd_desc = mod:localize("cmd_desc"),
	not_psykhanium = mod:localize("msg_not_psykhanium"),
	busy = mod:localize("msg_busy"),
	load_failed = mod:localize("msg_load_failed"),
}

local _session = nil

local function _call_name(object, method_name)
	if type(object) ~= "table" or type(object[method_name]) ~= "function" then
		return nil
	end
	local ok, name = pcall(object[method_name], object)
	return ok and name or nil
end

function mod.is_in_psykhanium()
	local state = Managers and Managers.state
	if not state then
		return false
	end
	if _call_name(state.game_mode, "game_mode_name") == PSYKHANIUM_GAME_MODE then
		return true
	end
	return _call_name(state.mission, "mission_name") == PSYKHANIUM_MISSION
end

function mod.echo_private(text)
	mod:echo("%s", tostring(text))
end

local function _abort(reason_key)
	local session = _session
	if session == nil then
		return
	end
	_session = nil
	local ok, err = pcall(session.abort, session, reason_key)
	if not ok then
		mod:error("%s", tostring(err))
	end
end

local function _run()
	if _session ~= nil then
		mod.echo_private(L.busy)
		return
	end

	if not mod.is_in_psykhanium() then
		mod.echo_private(L.not_psykhanium)
		return
	end

	local ok_load, runner = pcall(mod.io_dofile, mod, RUNNER_PATH)
	if not ok_load or type(runner) ~= "table" or type(runner.start) ~= "function" then
		mod:error("%s", tostring(runner))
		mod.echo_private(L.load_failed)
		return
	end

	local ok_start, session = pcall(runner.start)
	if not ok_start then
		mod:error("%s", tostring(session))
		mod.echo_private(L.load_failed)
		return
	end

	_session = session
end

mod:command("gbm_diag", L.cmd_desc, _run)

mod.update = function(dt)
	local session = _session
	if session == nil then
		return
	end

	local ok, finished = pcall(session.update, session, type(dt) == "number" and dt or 0)
	if not ok then
		mod:error("%s", tostring(finished))
		_abort("reason_error")
	elseif finished then
		_session = nil
	end
end

mod.on_game_state_changed = function(status, state_name)
	_abort("reason_state")
end

mod.on_unload = function(exit_game)
	_abort("reason_unload")
end
