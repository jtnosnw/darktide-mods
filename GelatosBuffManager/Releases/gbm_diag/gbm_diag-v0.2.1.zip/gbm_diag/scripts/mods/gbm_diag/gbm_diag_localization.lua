return {
	mod_name = {
		en = "GBM Diagnostics",
	},
	mod_description = {
		en = "Troubleshooting tool for Gelato's Buff Manager. Type /gbm_diag in chat while in the Psykhanium. Read-only: never changes your bars or settings.",
	},
	cmd_desc = {
		en = "Run Gelato's Buff Manager diagnostics (Psykhanium only).",
	},
	msg_not_psykhanium = {
		en = "GBM Diagnostics can only be run in the Psykhanium.",
	},
	msg_busy = {
		en = "GBM Diagnostics is already running. Please wait for it to finish.",
	},
	msg_load_failed = {
		en = "GBM Diagnostics failed to start. See the console log for details.",
	},
	msg_leak_started = {
		en = "GBM Diagnostics: checks done, memory test running for about %d seconds. Stay in the Psykhanium and keep menus closed.",
	},
	msg_done = {
		en = "GBM Diagnostics finished: %d PASS, %d WARN, %d FAIL. Report: %s",
	},
	msg_aborted = {
		en = "GBM Diagnostics memory test stopped early (%s). Partial report: %s",
	},
	msg_log_fallback = {
		en = "GBM Diagnostics could not write the report file, so the report was written to the console log instead.",
	},
	reason_left = {
		en = "left the Psykhanium",
	},
	reason_menu = {
		en = "a menu or the GBM window was open",
	},
	reason_hud = {
		en = "the HUD was unavailable",
	},
	reason_gbm_disabled = {
		en = "Gelato's Buff Manager was disabled",
	},
	reason_state = {
		en = "the game state changed",
	},
	reason_unload = {
		en = "mods were reloaded",
	},
	reason_error = {
		en = "an internal error occurred",
	},
}
