local mod = get_mod("gbm_diag")

return {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	version = mod:io_dofile("gbm_diag/scripts/mods/gbm_diag/gbm_diag_version"),
	is_togglable = false,
}
