local mod = get_mod("gbm_diag")

local LOG_DIR_SUBPATH = "\\Fatshark\\Darktide\\console_logs\\"
local LOG_NAME_FORMAT = "gbm_diag_%s_UTC.log"
local FILE_TIME_FORMAT = "!%Y-%m-%d_%H-%M-%S"
local TIME_FORMAT = "!%Y-%m-%dT%H:%M:%SZ"
local UNKNOWN_STAMP = "0000-00-00T00:00:00Z"
local MAX_DEPTH = 32

local GBM_SETTING_IDS = {
	"buffs_data",
	"bars",
	"bar_active_states",
	"gbm_bar_growth",
	"gbm_bar_slots",
	"gbm_buff_priorities",
	"default_buff_bar_enabled",
	"group_buffs_in_categories",
	"configure_buffs",
	"buffs_catalog",
	"nav_icon_scale",
	"max_buffs_per_bar",
}

local Util = {}

-- ---- Log ----

local Log = {}
Log.__index = Log

local function _loader_libs()
	local ok, io_lib, os_lib = pcall(function()
		local libs = Mods.lua
		return libs.io, libs.os
	end)
	if not ok then
		return nil, nil
	end
	return io_lib, os_lib
end

local function _date(os_lib, format)
	if os_lib and type(os_lib.date) == "function" then
		local ok, value = pcall(os_lib.date, format)
		if ok and type(value) == "string" then
			return value
		end
	end
	return nil
end

function Util.new_log()
	local io_lib, os_lib = _loader_libs()
	local path = nil
	local run_time = _date(os_lib, FILE_TIME_FORMAT)

	if run_time and os_lib and type(os_lib.getenv) == "function" then
		local ok, appdata = pcall(os_lib.getenv, "APPDATA")
		if ok and type(appdata) == "string" and appdata ~= "" then
			path = appdata .. LOG_DIR_SUBPATH .. LOG_NAME_FORMAT:format(run_time)
		end
	end

	return setmetatable({
		lines = {},
		count = 0,
		io = io_lib,
		os = os_lib,
		path = path,
		failed = false,
	}, Log)
end

function Log:stamp()
	return _date(self.os, TIME_FORMAT) or UNKNOWN_STAMP
end

function Log:write(text)
	local count = self.count + 1
	self.count = count
	self.lines[count] = "[" .. self:stamp() .. "] " .. tostring(text)
end

local function _write_file(io_lib, path, lines, count)
	local file = io_lib.open(path, "a")
	if not file then
		return false
	end
	local ok, result = pcall(file.write, file, table.concat(lines, "\n", 1, count), "\n")
	pcall(file.close, file)
	return ok and result ~= nil
end

function Log:flush()
	local count = self.count
	if count == 0 then
		return not self.failed
	end

	local lines = self.lines
	local written = false

	if self.io and self.path and type(self.io.open) == "function" then
		local ok, result = pcall(_write_file, self.io, self.path, lines, count)
		written = ok and result
	end

	if not written then
		self.failed = true
		for i = 1, count do
			mod:info("%s", lines[i])
		end
	end

	for i = count, 1, -1 do
		lines[i] = nil
	end
	self.count = 0

	return written
end

function Log:display_path()
	return self.path or "console log"
end

-- ---- Report ----

local Report = {}
Report.__index = Report

function Util.new_report(log)
	return setmetatable({ log = log, n_pass = 0, n_warn = 0, n_fail = 0, n_info = 0 }, Report)
end

function Report:line(text)
	self.log:write(text)
end

function Report:section(title)
	self.log:write("---- " .. title .. " ----")
end

function Report:ok(text)
	self.n_pass = self.n_pass + 1
	self.log:write("PASS  " .. text)
end

function Report:warn(text)
	self.n_warn = self.n_warn + 1
	self.log:write("WARN  " .. text)
end

function Report:fail(text)
	self.n_fail = self.n_fail + 1
	self.log:write("FAIL  " .. text)
end

function Report:info(text)
	self.n_info = self.n_info + 1
	self.log:write("INFO  " .. text)
end

function Report:expect(condition, text, fail_detail)
	if condition then
		self:ok(text)
	elseif fail_detail then
		self:fail(text .. " - " .. fail_detail)
	else
		self:fail(text)
	end
end

-- ---- Helpers ----

function Util.nonempty(value)
	return type(value) == "string" and value ~= ""
end

function Util.has_fn(tbl, name)
	return type(tbl) == "table" and type(tbl[name]) == "function"
end

function Util.global(name)
	return rawget(_G, name)
end

function Util.safe_require(path)
	local ok, result = pcall(require, path)
	if ok then
		return result
	end
	return nil
end

function Util.call(object, method_name, ...)
	if not Util.has_fn(object, method_name) then
		return nil
	end
	local ok, result = pcall(object[method_name], object, ...)
	if ok then
		return result
	end
	return nil
end

function Util.sorted_keys(tbl)
	local keys = {}
	for key in pairs(tbl) do
		keys[#keys + 1] = tostring(key)
	end
	table.sort(keys)
	return keys
end

function Util.count(tbl)
	local n = 0
	if type(tbl) == "table" then
		for _ in pairs(tbl) do
			n = n + 1
		end
	end
	return n
end

function Util.pascal(name)
	local convert = string.to_pascal_case
	if type(convert) == "function" then
		local ok, result = pcall(convert, name, " ")
		if ok and type(result) == "string" then
			return result
		end
	end
	return tostring(name)
end

function Util.current_hud()
	local ui = Managers and Managers.ui
	return ui and ui._hud or nil
end

-- ---- Settings snapshot ----

local function _copy(value, depth)
	if type(value) ~= "table" or depth > MAX_DEPTH then
		return value
	end
	local out = {}
	for key, item in pairs(value) do
		out[key] = _copy(item, depth + 1)
	end
	return out
end

local function _equal(a, b, depth)
	if a == b then
		return true
	end
	if type(a) ~= "table" or type(b) ~= "table" or depth > MAX_DEPTH then
		return false
	end
	for key, item in pairs(a) do
		if not _equal(item, b[key], depth + 1) then
			return false
		end
	end
	for key in pairs(b) do
		if a[key] == nil then
			return false
		end
	end
	return true
end

local function _collect_widget_ids(widgets, ids, seen)
	if type(widgets) ~= "table" then
		return
	end
	for _, widget in ipairs(widgets) do
		if type(widget) == "table" then
			local id = widget.setting_id
			if Util.nonempty(id) and widget.type ~= "group" and not seen[id] then
				seen[id] = true
				ids[#ids + 1] = id
			end
			_collect_widget_ids(widget.sub_widgets, ids, seen)
		end
	end
end

function Util.gbm_setting_ids(gbm)
	local ids, seen = {}, {}
	for i = 1, #GBM_SETTING_IDS do
		local id = GBM_SETTING_IDS[i]
		seen[id] = true
		ids[i] = id
	end
	local options = Util.call(gbm, "get_internal_data", "options")
	if type(options) == "table" then
		_collect_widget_ids(options.widgets, ids, seen)
	end
	return ids
end

function Util.gbm_get(gbm, setting_id)
	return Util.call(gbm, "get", setting_id)
end

function Util.snapshot_settings(gbm, ids)
	local snapshot = {}
	for i = 1, #ids do
		snapshot[ids[i]] = _copy(Util.gbm_get(gbm, ids[i]), 0)
	end
	return snapshot
end

function Util.changed_settings(gbm, ids, snapshot)
	local changed = {}
	for i = 1, #ids do
		local id = ids[i]
		if not _equal(Util.gbm_get(gbm, id), snapshot[id], 0) then
			changed[#changed + 1] = id
		end
	end
	return changed
end

return Util
