local mod = get_mod("gbm_diag")

local GBM_BAR_PREFIX = "GBMHudElementBuffBar"
local VANILLA_BUFFS_CLASS = "HudElementPlayerBuffs"
local START_DELAY = 1.5
local STEP_INTERVAL = 1
local SETTLE_DELAY = 2
local WARMUP_MAX = 5
local GROWTH_WARN_KB = 64
local WEAK_KEYS = { __mode = "k" }

local Leak = {}
Leak.__index = Leak

local function _collect()
	if type(collectgarbage) ~= "function" then
		return nil
	end
	collectgarbage("collect")
	collectgarbage("collect")
	return collectgarbage("count")
end

local function _count_retained(weak, current)
	local count = 0
	for object in pairs(weak) do
		if not current[object] then
			count = count + 1
		end
	end
	return count
end

function Leak.duration(rebuilds)
	return math.ceil(START_DELAY + rebuilds * STEP_INTERVAL + SETTLE_DELAY)
end

function Leak.new(ctx, rebuilds, on_finish)
	return setmetatable({
		ctx = ctx,
		on_finish = on_finish,
		rebuilds = rebuilds,
		warmup = math.min(WARMUP_MAX, math.floor(rebuilds / 4)),
		phase = "start",
		timer = START_DELAY,
		done = 0,
		skipped = 0,
		mismatches = 0,
		last_mismatch = nil,
		baseline_count = nil,
		vanilla_seen = false,
		finished = false,
		gbm_elements = setmetatable({}, WEAK_KEYS),
		vanilla_elements = setmetatable({}, WEAK_KEYS),
		huds = setmetatable({}, WEAK_KEYS),
	}, Leak)
end

function Leak:_track()
	local hud = self.ctx.U.current_hud()
	local elements = hud and hud._elements
	if type(elements) ~= "table" then
		return nil
	end
	self.huds[hud] = true
	local count = 0
	for name, element in pairs(elements) do
		if type(element) == "table" then
			if type(name) == "string" and name:sub(1, #GBM_BAR_PREFIX) == GBM_BAR_PREFIX then
				count = count + 1
				self.gbm_elements[element] = true
			elseif name == VANILLA_BUFFS_CLASS then
				self.vanilla_seen = true
				self.vanilla_elements[element] = true
			end
		end
	end
	return count
end

function Leak:_guard()
	if not mod.is_in_psykhanium() then
		return "reason_left"
	end
	local ui = Managers and Managers.ui
	if not ui or not ui._hud then
		return "reason_hud"
	end
	if type(ui.using_input) == "function" then
		local ok, busy = pcall(ui.using_input, ui)
		if ok and busy then
			return "reason_menu"
		end
	end
	local gbm = self.ctx.gbm
	if not gbm or self.ctx.U.call(gbm, "is_enabled") ~= true or type(gbm.recreate_hud) ~= "function" then
		return "reason_gbm_disabled"
	end
	return nil
end

function Leak:_rebuild()
	local U = self.ctx.U
	local before = U.current_hud()
	local ok = pcall(self.ctx.gbm.recreate_hud)
	if not ok or U.current_hud() == before then
		self.skipped = self.skipped + 1
	end
	self.done = self.done + 1
end

function Leak:update(dt)
	if self.finished then
		return true
	end

	self.timer = self.timer - dt
	if self.timer > 0 then
		return false
	end

	local reason = self:_guard()
	if reason then
		self:abort(reason)
		return true
	end

	local phase = self.phase

	if phase == "start" then
		self.baseline_count = self:_track()
		self.mem_start = _collect()
		self.phase = "rebuild"
		self.timer = 0
		return false
	end

	if phase == "rebuild" then
		if self.done > 0 then
			local count = self:_track()
			if count ~= self.baseline_count then
				self.mismatches = self.mismatches + 1
				self.last_mismatch = count
			end
			if self.done == self.warmup then
				self.mem_warm = _collect()
			end
		end
		if self.done >= self.rebuilds then
			self.phase = "settle"
			self.timer = SETTLE_DELAY
			return false
		end
		self:_rebuild()
		self.timer = STEP_INTERVAL
		return false
	end

	self.mem_end = _collect()
	self:_report(false)
	self:_finish(nil)
	return true
end

function Leak:_report(aborted)
	local ctx = self.ctx
	local R, U = ctx.report, ctx.U
	R:section("7. Memory leak test")
	R:info(("HUD rebuilds completed: %d of %d (one per second)"):format(self.done, self.rebuilds))

	local baseline = self.baseline_count
	if baseline ~= nil then
		local expected = ctx.expected_element_count or 0
		if baseline == expected then
			R:ok(("GBM bars on the HUD at start: %d, matching saved settings"):format(baseline))
		else
			R:warn(("GBM bars on the HUD at start: %d, but saved settings expect %d"):format(baseline, expected))
		end
	end

	if self.done > 0 then
		R:expect(self.skipped == 0, "every rebuild replaced the HUD",
			("%d rebuild(s) left the old HUD in place"):format(self.skipped))
		if baseline ~= nil then
			R:expect(self.mismatches == 0, "every rebuild recreated the same number of GBM bars",
				("%d rebuild(s) differed; last one had %s"):format(self.mismatches, tostring(self.last_mismatch)))
		end
	end

	if aborted then
		R:info("memory results skipped - test stopped early")
		return
	end

	local mem_start, mem_warm, mem_end = self.mem_start, self.mem_warm, self.mem_end
	local measured = self.done - self.warmup
	if mem_start and mem_warm and mem_end and measured > 0 then
		local growth = (mem_end - mem_warm) / measured
		R:info(("Lua memory: start %.1f KB, after %d warm-up rebuilds %.1f KB, end %.1f KB"):format(
			mem_start, self.warmup, mem_warm, mem_end))
		if growth <= GROWTH_WARN_KB then
			R:ok(("memory growth %.1f KB per rebuild (limit %d KB)"):format(growth, GROWTH_WARN_KB))
		else
			R:warn(("memory growth %.1f KB per rebuild (limit %d KB) - possible leak; run again standing still with no enemies spawned to rule out background noise"):format(
				growth, GROWTH_WARN_KB))
		end
	else
		R:info("Lua memory measurement unavailable")
	end

	if baseline == nil then
		R:warn("HUD element list unavailable - freed-element tracking skipped (see patch compatibility: UIHud._elements)")
		return
	end

	local current = {}
	local hud = U.current_hud()
	if hud then
		current[hud] = true
		if type(hud._elements) == "table" then
			for _, element in pairs(hud._elements) do
				current[element] = true
			end
		end
	end

	local gbm_retained = _count_retained(self.gbm_elements, current)
	local vanilla_retained = _count_retained(self.vanilla_elements, current)
	local huds_retained = _count_retained(self.huds, current)

	if gbm_retained == 0 then
		R:ok("all replaced GBM bar elements were freed")
	elseif vanilla_retained > 0 then
		R:warn(("%d replaced GBM bar element(s) still in memory, but so are %d vanilla buff bar(s) - the game is holding old HUD elements, likely not a GBM leak"):format(
			gbm_retained, vanilla_retained))
	elseif not self.vanilla_seen then
		R:warn(("%d replaced GBM bar element(s) still in memory; no vanilla buff bar to compare against (default bar hidden) - enable it and run again to confirm"):format(
			gbm_retained))
	else
		R:fail(("%d replaced GBM bar element(s) still in memory while vanilla buff bars were freed - likely a GBM leak"):format(
			gbm_retained))
	end

	if huds_retained == 0 then
		R:ok("all replaced HUDs were freed")
	else
		R:warn(("%d replaced HUD(s) still in memory"):format(huds_retained))
	end

	if self.done > 0 then
		R:ok("HUD left in its normal state (the last step was a regular rebuild)")
	end
end

function Leak:_finish(reason_key)
	if self.finished then
		return
	end
	self.finished = true
	local ctx, on_finish = self.ctx, self.on_finish
	self.ctx = nil
	self.on_finish = nil
	on_finish(ctx, reason_key)
end

function Leak:abort(reason_key)
	if self.finished then
		return
	end
	local ok, err = pcall(self._report, self, true)
	if not ok then
		self.ctx.report:fail("leak test report failed: " .. tostring(err))
	end
	self:_finish(reason_key or "reason_error")
end

return Leak
