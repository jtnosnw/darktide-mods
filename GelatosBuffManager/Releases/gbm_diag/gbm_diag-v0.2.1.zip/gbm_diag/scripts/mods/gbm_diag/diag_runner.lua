local mod = get_mod("gbm_diag")

local BASE_PATH = "gbm_diag/scripts/mods/gbm_diag/"
local LEAK_REBUILDS = 20
local SLOTS_SETTING_ID = "gbm_bar_slots"

local L = {
	log_fallback = mod:localize("msg_log_fallback"),
}

local Runner = {}

local function _run_section(ctx, name, fn)
	local ok, err = pcall(fn, ctx)
	if not ok then
		ctx.report:fail(("section '%s' stopped with an error: %s"):format(name, tostring(err)))
	end
end

local function _header(ctx)
	local R, U, gbm = ctx.report, ctx.U, ctx.gbm
	R:line(("==== GBM Diagnostics v%s ===="):format(tostring(mod.version)))

	if gbm then
		R:line(("Gelato's Buff Manager: v%s (enabled: %s)"):format(
			tostring(gbm.version), tostring(U.call(gbm, "is_enabled"))))
	else
		R:line("Gelato's Buff Manager: not loaded - only game-side checks will run")
	end

	local build = nil
	local application = U.global("Application")
	if type(application) == "table" and type(application.build_identifier) == "function" then
		local ok, result = pcall(application.build_identifier)
		build = ok and result or nil
	end
	R:line("Game build: " .. tostring(build or "unknown"))

	local state = Managers and Managers.state
	R:line(("Location: game mode %s, mission %s"):format(
		tostring(state and U.call(state.game_mode, "game_mode_name")),
		tostring(state and U.call(state.mission, "mission_name"))))
	R:line("Read-only run: GBM settings are compared before and after")
end

local function _skip_leak(ctx, text)
	ctx.report:section("7. Memory leak test")
	ctx.report:info(text)
end

function Runner.finish(ctx, reason_key)
	local R, U, gbm = ctx.report, ctx.U, ctx.gbm
	R:section("Summary")

	local settings_line = "Settings unchanged: SKIPPED (Gelato's Buff Manager not loaded)"
	if gbm and ctx.setting_ids then
		local ok, changed = pcall(U.changed_settings, gbm, ctx.setting_ids, ctx.snapshot)
		if not ok then
			R.n_fail = R.n_fail + 1
			settings_line = "Settings unchanged: FAIL (comparison error: " .. tostring(changed) .. ")"
		elseif #changed == 0 then
			R.n_pass = R.n_pass + 1
			settings_line = "Settings unchanged: PASS"
		else
			R.n_fail = R.n_fail + 1
			local note = ""
			if #changed == 1 and changed[1] == SLOTS_SETTING_ID then
				note = " - GBM itself saves a screen slot for a newly active bar when the HUD is rebuilt"
			end
			settings_line = "Settings unchanged: FAIL (changed: " .. table.concat(changed, ", ") .. ")" .. note
		end
	end

	if reason_key then
		R:line("Run stopped early: " .. tostring(reason_key))
	end
	R:line(("Totals: %d PASS, %d WARN, %d FAIL, %d INFO"):format(R.n_pass, R.n_warn, R.n_fail, R.n_info))
	R:line(settings_line)

	local log = ctx.log
	local written = log:flush()
	local path = written and log:display_path() or "console log"

	if reason_key then
		mod.echo_private(mod:localize("msg_aborted", mod:localize(reason_key), path))
	else
		mod.echo_private(mod:localize("msg_done", R.n_pass, R.n_warn, R.n_fail, path))
	end
	if not written then
		mod.echo_private(L.log_fallback)
	end

	ctx.snapshot = nil
	ctx.setting_ids = nil
	ctx.settings = nil
	ctx.filters = nil
	ctx.element_bars = nil
	ctx.live_elements = nil
end

function Runner.start()
	local U = mod:io_dofile(BASE_PATH .. "diag_util")
	local Checks = mod:io_dofile(BASE_PATH .. "diag_checks")
	local log = U.new_log()
	local ctx = { U = U, log = log, report = U.new_report(log) }

	local ok_gbm, gbm = pcall(get_mod, "gelatos_buff_manager")
	ctx.gbm = ok_gbm and gbm or nil
	if ctx.gbm then
		ctx.setting_ids = U.gbm_setting_ids(ctx.gbm)
		ctx.snapshot = U.snapshot_settings(ctx.gbm, ctx.setting_ids)
	end

	_run_section(ctx, "header", _header)
	_run_section(ctx, "prepare", Checks.prepare)

	local ok_index, index = pcall(Checks.build_index, ctx)
	ctx.index = ok_index and index or nil
	if not ok_index then
		ctx.report:fail("catalog index build stopped with an error: " .. tostring(index))
	end

	_run_section(ctx, "0. Screen and bar layout", Checks.layout)
	_run_section(ctx, "1. Patch compatibility", Checks.compat)
	_run_section(ctx, "2. Saved assignments vs game", Checks.saved_vs_game)
	_run_section(ctx, "3. Catalog health", Checks.catalog)
	_run_section(ctx, "4. Settings integrity", Checks.integrity)
	_run_section(ctx, "5. Conflict check", Checks.conflicts)
	_run_section(ctx, "6. Live buff snapshot", Checks.live)

	ctx.index = nil
	ctx.classifier = nil
	log:flush()

	local gbm_ready = ctx.gbm and U.call(ctx.gbm, "is_enabled") == true and type(ctx.gbm.recreate_hud) == "function"
	if not gbm_ready then
		_skip_leak(ctx, "skipped - Gelato's Buff Manager is not loaded or not enabled")
		Runner.finish(ctx, nil)
		return nil
	end

	local Leak = mod:io_dofile(BASE_PATH .. "diag_leak")
	local session = Leak.new(ctx, LEAK_REBUILDS, Runner.finish)
	mod.echo_private(mod:localize("msg_leak_started", Leak.duration(LEAK_REBUILDS)))
	return session
end

return Runner
